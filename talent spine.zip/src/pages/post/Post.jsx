import React from 'react'

const Post = () => {
  return (
    <div className=' text-center py-20 text-3xl'>
    Post
    
  </div>
  )
}

export default Post
