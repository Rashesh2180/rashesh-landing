import React from 'react'

const Service = () => {
  return (
    <div className=' text-center py-20 text-3xl'>
    Service
    
  </div>
  )
}

export default Service
