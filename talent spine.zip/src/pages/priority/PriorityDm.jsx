import React from 'react'

const PriorityDm = () => {
  return (
    <div className=' text-center py-20 text-3xl'>
      Priority dm
      
    </div>
  )
}

export default PriorityDm
