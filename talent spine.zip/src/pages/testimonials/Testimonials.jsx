import React from 'react'

const Testimonials = () => {
  return (
    <div className=' text-center py-20 text-3xl'>
      Testimonials
      
    </div>
  )
}

export default Testimonials
