import React from 'react'

const SwiperPrevButton = () => {
  return (
    <div>
      
    </div>
  )
}

export default SwiperPrevButton
