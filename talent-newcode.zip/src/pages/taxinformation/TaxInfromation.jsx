import React from 'react'

const TaxInfromation = () => {
  return (
    <div className=' text-center py-20 text-3xl'>
    TaxInfromation
    
  </div>
  )
}

export default TaxInfromation
