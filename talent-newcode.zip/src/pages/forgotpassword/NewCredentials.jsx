import React from 'react'

const NewCredentials = () => {
  return (
    <div>
      ddd
      
    </div>
  )
}

export default NewCredentials
