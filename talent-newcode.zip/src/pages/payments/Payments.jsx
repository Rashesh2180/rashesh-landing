import React from 'react'

const Payments = () => {
  return (
    <div className=' text-center py-20 text-3xl'>
    Payments
    
  </div>
  )
}

export default Payments
