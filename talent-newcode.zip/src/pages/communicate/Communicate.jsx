import React from 'react'

const Communicate = () => {
  return (
    <div className=' text-center py-20 text-3xl'>
    Communicate
    
  </div>
  )
}

export default Communicate
