import React from 'react'

const SalesReport = () => {
  return (
    <div className=' text-center py-20 text-3xl'>
    SalesReport
    
  </div>
  )
}

export default SalesReport
