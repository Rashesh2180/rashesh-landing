import React from 'react'

const Calender = () => {
  return (
    <div className=' text-center py-20 text-3xl'>
    Calender
    
  </div>
  )
}

export default Calender
