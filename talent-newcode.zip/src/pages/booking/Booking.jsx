import React from 'react'

const Booking = () => {
  return (
    <div className=' text-center py-20 text-3xl'>
      Booking
      
    </div>
  )
}

export default Booking
