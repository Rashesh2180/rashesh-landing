export const navlist =[{
    list:"home",
    href:"",

}
,
{
    list:"find talent",
    href:"",
    
},
{
    list:"Project Packages",
    href:"",
    
},
{
    list:"Find work",
    href:"",
    
}
]